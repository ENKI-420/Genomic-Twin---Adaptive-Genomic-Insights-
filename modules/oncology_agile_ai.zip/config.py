# Configuration settings for oncology AI platform
API_KEY = "YOUR_API_KEY"
BASE_URL = "https://api.oncology.ai"
