# Utility functions for the platform
def calculate_risk(factor1, factor2):
    return factor1 * factor2
