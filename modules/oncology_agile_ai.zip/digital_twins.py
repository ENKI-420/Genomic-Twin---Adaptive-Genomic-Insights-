# Digital Twin Simulation
def generate_digital_twin(patient_data, therapies, days):
    # Mock function to simulate digital twin data
    return pd.DataFrame({"day": range(1, days+1), "tumor_volume": [100, 95, 90, 85, 80]})
